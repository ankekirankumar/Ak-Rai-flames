import { useState } from 'react'
import Header from './components/Header.jsx'
import Home from './components/Home.jsx'
import History from './components/History.jsx'
import About from './components/About.jsx'

export default function App() {
  const [view, setView] = useState('home')

  return (
    <div className="app-shell">
      <Header view={view} onNavigate={setView} />
      <main className="app-main">
        {view === 'home' && <Home />}
        {view === 'history' && <History />}
        {view === 'about' && <About />}
      </main>
      <footer className="app-footer">
        <p>AK RAI · FLAMES</p>
      </footer>
    </div>
  )
}
