import { useState } from 'react'
import { calculateFlames, FLAMES_MEANINGS } from '../lib/flames'
import { saveFlamesCheck } from '../lib/flamesApi'

const MAX_LEN = 40

const initialForm = { username: '', name1: '', name2: '' }
const initialErrors = { username: '', name1: '', name2: '' }

export default function Home() {
  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState(initialErrors)
  const [result, setResult] = useState(null)
  const [saveState, setSaveState] = useState('idle') // idle | saving | saved | failed
  const [saveMessage, setSaveMessage] = useState('')

  function updateField(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
    if (errors[field]) setErrors((e) => ({ ...e, [field]: '' }))
  }

  function validate() {
    const trimmed = {
      username: form.username.trim(),
      name1: form.name1.trim(),
      name2: form.name2.trim(),
    }
    const nextErrors = { username: '', name1: '', name2: '' }

    if (!trimmed.username) nextErrors.username = 'Enter a username.'
    else if (trimmed.username.length > MAX_LEN) nextErrors.username = `Keep it under ${MAX_LEN} characters.`

    if (!trimmed.name1) nextErrors.name1 = 'Enter the first name.'
    else if (trimmed.name1.length > MAX_LEN) nextErrors.name1 = `Keep it under ${MAX_LEN} characters.`

    if (!trimmed.name2) nextErrors.name2 = 'Enter the second name.'
    else if (trimmed.name2.length > MAX_LEN) nextErrors.name2 = `Keep it under ${MAX_LEN} characters.`

    setErrors(nextErrors)
    const isValid = !nextErrors.username && !nextErrors.name1 && !nextErrors.name2
    return { isValid, trimmed }
  }

  async function handleCalculate(e) {
    e.preventDefault()
    const { isValid, trimmed } = validate()
    if (!isValid) return

    const flamesResult = calculateFlames(trimmed.name1, trimmed.name2)
    setResult(flamesResult)
    setSaveState('saving')
    setSaveMessage('')

    const { error } = await saveFlamesCheck({
      username: trimmed.username,
      name1: trimmed.name1,
      name2: trimmed.name2,
      result: flamesResult.word,
    })

    if (error) {
      setSaveState('failed')
      setSaveMessage("Result calculated, but we couldn't save your check. Please try again.")
    } else {
      setSaveState('saved')
      setSaveMessage('Saved to your FLAMES history.')
    }
  }

  function handleReset() {
    setForm(initialForm)
    setErrors(initialErrors)
    setResult(null)
    setSaveState('idle')
    setSaveMessage('')
  }

  return (
    <>
      <section className="hero">
        <div className="hero-flame" aria-hidden="true">
          <svg viewBox="0 0 100 130" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M50 4c3 14-4 22-11 31C31 45 24 56 24 70c0 24 12 40 26 40 17 0 30-14 30-33 0-13-6-22-14-30 2 10-1 16-6 20-1-11-4-19-10-27C46 30 44 16 50 4z"
              fill="url(#heroFlame)"
            />
            <defs>
              <linearGradient id="heroFlame" x1="24" y1="4" x2="80" y2="110" gradientUnits="userSpaceOnUse">
                <stop stopColor="#ffcb6b" />
                <stop offset="0.45" stopColor="#f5539a" />
                <stop offset="1" stopColor="#7c4fe0" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <h1>FLAMES</h1>
        <p className="hero-subtitle">Two names in, one verdict out — the name game everyone played on the back of a notebook.</p>
      </section>

      <section className="card form-card" aria-label="Calculate your FLAMES result">
        <form onSubmit={handleCalculate} noValidate>
          <div className="field">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              type="text"
              placeholder="Enter username"
              value={form.username}
              onChange={(e) => updateField('username', e.target.value)}
              maxLength={MAX_LEN + 10}
              aria-invalid={!!errors.username}
              aria-describedby={errors.username ? 'username-error' : undefined}
            />
            {errors.username && (
              <p className="field-error" id="username-error">{errors.username}</p>
            )}
          </div>

          <div className="field">
            <label htmlFor="name1">Name 1</label>
            <input
              id="name1"
              type="text"
              placeholder="Enter first name"
              value={form.name1}
              onChange={(e) => updateField('name1', e.target.value)}
              maxLength={MAX_LEN + 10}
              aria-invalid={!!errors.name1}
              aria-describedby={errors.name1 ? 'name1-error' : undefined}
            />
            {errors.name1 && <p className="field-error" id="name1-error">{errors.name1}</p>}
          </div>

          <div className="field">
            <label htmlFor="name2">Name 2</label>
            <input
              id="name2"
              type="text"
              placeholder="Enter second name"
              value={form.name2}
              onChange={(e) => updateField('name2', e.target.value)}
              maxLength={MAX_LEN + 10}
              aria-invalid={!!errors.name2}
              aria-describedby={errors.name2 ? 'name2-error' : undefined}
            />
            {errors.name2 && <p className="field-error" id="name2-error">{errors.name2}</p>}
          </div>

          <div className="actions">
            <button type="submit" className="btn-primary">
              Calculate FLAMES <span aria-hidden="true">🔥</span>
            </button>
            <button type="button" className="btn-secondary" onClick={handleReset}>
              Reset
            </button>
          </div>
        </form>
      </section>

      {result && (
        <section className={`card result-card reveal ${saveState}`} aria-live="polite">
          {result.letter ? (
            <>
              <span className="result-letter">{result.letter}</span>
              <h2>{result.word}</h2>
            </>
          ) : (
            <h2>{result.word}</h2>
          )}
          <p className="result-blurb">{result.blurb}</p>

          <p className={`save-status save-status--${saveState}`}>
            {saveState === 'saving' && 'Saving your check…'}
            {saveState === 'saved' && saveMessage}
            {saveState === 'failed' && saveMessage}
          </p>
        </section>
      )}

      <section className="card meanings-card" aria-label="What does FLAMES mean?">
        <h2>What does FLAMES mean?</h2>
        <p className="meanings-subtitle">Six playful outcomes, one classic name game.</p>
        <div className="meanings-grid">
          {Object.entries(FLAMES_MEANINGS).map(([letter, meaning]) => (
            <div className="meaning-tile" key={letter}>
              <span className="meaning-letter">{letter}</span>
              <span className="meaning-word">{meaning.word}</span>
            </div>
          ))}
        </div>
      </section>
    </>
  )
}
