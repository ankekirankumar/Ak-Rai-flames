export default function About() {
  return (
    <section className="card about-card" aria-label="About AK RAI">
      <h2>About AK RAI</h2>
      <p>
        AK RAI built this FLAMES app as a quick, lighthearted way to revisit the name-matching game
        people have scribbled in notebook margins for decades — Friends, Love, Affection, Marriage,
        Enemies, Siblings.
      </p>
      <p>
        Enter two names, get an instant result, and see it join the running history of every check
        made in the app. No accounts, no email — just names and a verdict.
      </p>
    </section>
  )
}
