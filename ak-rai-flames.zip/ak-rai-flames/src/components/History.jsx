import { useEffect, useState } from 'react'
import { getFlamesHistory } from '../lib/flamesApi'

function formatDateTime(isoString) {
  try {
    return new Date(isoString).toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  } catch {
    return isoString
  }
}

export default function History() {
  const [rows, setRows] = useState([])
  const [status, setStatus] = useState('loading') // loading | ready | error

  useEffect(() => {
    let cancelled = false
    async function load() {
      setStatus('loading')
      const { data, error } = await getFlamesHistory()
      if (cancelled) return
      if (error) {
        setStatus('error')
      } else {
        setRows(data)
        setStatus('ready')
      }
    }
    load()
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <section className="card history-card" aria-label="FLAMES history">
      <h2>History</h2>
      <p className="history-note">
        This history is public — there's no login in this version, so every check saved here is visible to
        anyone using the app.
      </p>

      {status === 'loading' && <p className="history-state">Loading past checks…</p>}
      {status === 'error' && <p className="history-state history-state--error">Couldn't load history right now. Please try again shortly.</p>}
      {status === 'ready' && rows.length === 0 && (
        <p className="history-state">No checks yet — be the first to calculate your FLAMES.</p>
      )}

      {status === 'ready' && rows.length > 0 && (
        <ul className="history-list">
          {rows.map((row) => (
            <li className="history-row" key={row.id}>
              <div className="history-row-top">
                <span className="history-names">{row.name1} &amp; {row.name2}</span>
                <span className="history-result">{row.result}</span>
              </div>
              <div className="history-row-bottom">
                <span className="history-user">@{row.username}</span>
                <span className="history-time">{formatDateTime(row.created_at)}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
