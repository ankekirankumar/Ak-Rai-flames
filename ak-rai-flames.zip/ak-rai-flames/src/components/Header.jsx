import { useState } from 'react'

const NAV_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'history', label: 'History' },
  { id: 'about', label: 'About FLAMES' },
]

export default function Header({ view, onNavigate }) {
  const [open, setOpen] = useState(false)

  function go(id) {
    onNavigate(id)
    setOpen(false)
  }

  return (
    <header className="header">
      <button className="brand" onClick={() => go('home')} aria-label="AK RAI home">
        <span className="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M12 2c.6 2.2-.4 3.6-1.6 5C9 9 8 10.6 8 12.8 8 16.8 10.4 19 13 19c2.9 0 5-2.2 5-5.2 0-2-1-3.4-2.2-4.6.4 1.6-.2 2.6-1 3.2-.2-1.8-.6-3-1.6-4.4C12 6.2 11.6 4.2 12 2z"
              fill="url(#flameGrad)"
            />
            <defs>
              <linearGradient id="flameGrad" x1="8" y1="2" x2="18" y2="19" gradientUnits="userSpaceOnUse">
                <stop stopColor="#ffb454" />
                <stop offset="0.55" stopColor="#f5539a" />
                <stop offset="1" stopColor="#8b5cf6" />
              </linearGradient>
            </defs>
          </svg>
        </span>
        <span className="brand-name">AK RAI</span>
      </button>

      <button
        className={`hamburger ${open ? 'is-open' : ''}`}
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Close menu' : 'Open menu'}
        aria-expanded={open}
      >
        <span />
        <span />
        <span />
      </button>

      <nav className={`nav-panel ${open ? 'is-open' : ''}`}>
        <ul>
          {NAV_ITEMS.map((item) => (
            <li key={item.id}>
              <button
                className={view === item.id ? 'is-active' : ''}
                onClick={() => go(item.id)}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {open && <button className="nav-scrim" aria-hidden="true" onClick={() => setOpen(false)} />}
    </header>
  )
}
